﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace WoodShops
{

    // Mirar porque creo que no he agregado en productos.
    enum TipoTablero
    {
        Aglomerado,
        Contrachapado,
        MDF
    }

    enum Color
    {
        Incoloro,
        Caoba,
        Nogal
    }

    enum TipoArticulo
    {
        Mesa,
        Silla,
        Armario,
        Estanteria
    }


    internal class EmpresaWood
    {
        public void Inicio()
        {
            Tienda tend = new Tienda();
            Provers provers = new Provers();
            EmpresaShops emp = new EmpresaShops();
            bool salir = false;
            string opcion;
            do
            {
                Console.WriteLine("1. Añadir nuevos productos en cada tienda ");
                Console.WriteLine("2. Listar los productos de una tienda con la opción de seleccionar por los tres tipos de producto: tablero, barniz o artículo ");
                Console.WriteLine("3. Dado un código de producto, mostrar el stock de cada una de las tiendas en que exista el producto ");
                Console.WriteLine("0. Salir");
                Console.ForegroundColor = ConsoleColor.Green;
                opcion = pedirOpcionMenu();
                Console.ForegroundColor = ConsoleColor.Gray;
                switch (opcion)
                {
                    case "1":
                        crearProductos(provers);
                        break;
                    case "2":
                        listarProductos(provers);
                        break;


                    case "3":
                        verificarProductos(tend);
                        break;


                    case "4":
                        eliminarProducto(emp);
                        break;
                    case "5":
                        listaProductos(provers);
                        break;
                    case "0":
                        salir = true;
                        break;
                }

            } while (!salir);
        }
        string pedirOpcionMenu()
        {
            string opcion;
            do
            {
                Console.Write("Opcion: ");
                opcion = Console.ReadLine();
            } while (!"012345".Contains(opcion));

            return opcion;

        }
        public void crearProductos(Provers provers)
        {

            Tablero tablero1 = new Tablero();
            tablero1.Ancho = 1;
            tablero1.Alto = 2;
            tablero1.Pvp = 22.50f;
            tablero1.Codigo = 1;  // este me da 23
            tablero1.Descripcion = "High quality";
            tablero1.Stock = 20;

            Tablero tablero2 = new Tablero();
            tablero2.Ancho = 3;
            tablero2.Alto = 4;
            tablero2.Pvp = 30.50f;
            tablero2.Codigo = 2;
            tablero2.Descripcion = "Premium quality";
            tablero2.Stock = 21;

            Tablero tablero3 = new Tablero();
            tablero3.Ancho = 1;
            tablero3.Alto = 2;
            tablero3.Pvp = 22.50f;
            tablero3.Codigo = 1;  // este me da 23
            tablero3.Descripcion = "High quality";
            tablero3.Stock = 30;

            Barniz barniz1 = new Barniz();
            barniz1.Ml = 10;
            barniz1.Pvp = 12.50f;
            barniz1.Codigo = 3;
            barniz1.Descripcion = "Premium quality";
            barniz1.Stock = 22;

            Barniz barniz2 = new Barniz();
            barniz2.Ml = 10;
            barniz2.Pvp = 14.50f;
            barniz2.Codigo = 4;
            barniz2.Descripcion = "Premium quality";
            barniz2.Stock = 32;

            Articulo articulo1 = new Articulo(); // este si funciona
            articulo1.Pvp = 12.50f;
            articulo1.Codigo = 5;  
            articulo1.Descripcion = "Less quality";
            articulo1.Stock = 24;

            Articulo articulo2 = new Articulo(); // este si funciona
            articulo2.Pvp = 13.50f;
            articulo2.Codigo = 6;
            articulo2.Descripcion = "Less quality";
            articulo2.Stock = 25;





            Tienda tienda1 = new Tienda();
            tienda1.Nombre = "Modas Lepanto";
            tienda1.addProductos(tablero1);
            tienda1.addProductos(barniz1);
            tienda1.addProductos(articulo1);

            if (provers.addTienda(tienda1) >= 0)
            {
                Console.WriteLine("\nLa Tienda se ha añadido correctamente\n");
            }
            else { Console.WriteLine("\nERROR: La Tienda NO ha añadido correctamente\n"); }


            Tienda tienda2 = new Tienda();
            tienda2.Nombre = "Modas Paco";
            tienda2.addProductos(tablero2);
            tienda2.addProductos(tablero3);
            tienda2.addProductos(barniz2);
            tienda2.addProductos(articulo2);



            if (provers.addTienda(tienda2) >= 0)
            {
                Console.WriteLine("\nLa Tienda se ha añadido correctamente\n");
            }
            else { Console.WriteLine("\nERROR: La Tienda NO ha añadido correctamente\n"); }


            Cliente cliente1 = new Cliente();
            cliente1.Nif = "11111111A";
            cliente1.Nombre = "Josep";


            Cliente cliente2 = new Cliente();
            cliente2.Nif = "22222222B";
            cliente2.Nombre = "David";

            provers.addCliente(cliente1);
            provers.addCliente(cliente2);



        }

        public void listarProductos(Provers provers)
        {

            Console.WriteLine("Listar los productos de una tienda con la opción de seleccionar por los tres tipos de producto: tablero, barniz o artículo");
            string opcion = Console.ReadLine();
            opcion.ToUpper();

            switch (opcion)
            {
                case "TABLERO":
                    foreach (Tienda tiendas in provers.Tiendas)
                    {
                        foreach (Productos produ in tiendas.getProductos())
                        {
                            if (produ is Tablero)
                            {
                                Console.WriteLine(produ.ToString());
                            }
                            Console.WriteLine();
                        }
                    }
                    break;

                case "ARTICULO":
                    foreach (Tienda tiendas in provers.Tiendas)
                    {
                        foreach (Productos produ in tiendas.getProductos())
                        {
                            if (produ is Articulo)
                            {
                                Console.WriteLine(produ.ToString());
                            }
                            Console.WriteLine();
                        }
                    }
                    break;

                case "BARNIZ":
                    foreach (Tienda tiendas in provers.Tiendas)
                    {
                        foreach (Productos produ in tiendas.getProductos())
                        {
                            if (produ is Barniz)
                            {
                                Console.WriteLine(produ.ToString());
                            }
                            Console.WriteLine();
                        }
                    }
                    break;

                default:
                    Console.WriteLine("Introducir un dato correcto");
                    break;

            }
        }







        public void verificarProductos(Tienda tend)
        {
            Console.Write("Cual es el producto que deseas mostrar, introducir el código: ");
            string respo = Console.ReadLine();


            foreach (Productos producto in tend.Productos)
            {
                if (producto.Codigo.Equals(respo))
                {
                    Console.WriteLine();
                }
            }

            Console.WriteLine();

        }



        
        public void eliminarProducto(EmpresaShops emp)
        {
            string codigo;

            Console.Write("Codigo: ");
            codigo = Console.ReadLine();

            foreach (Tienda tien in emp.Tiendas)
            {
                if (tien.removeProductos(codigo))
                {
                    Console.WriteLine("El producto se ha eliminado de la tienda " + tien.Nombre);
                }
            }
        }

        public void listaProductos(Provers provers)
        {
            int codigo;

            Console.Write("Que código deseas buscar? ");

            codigo = int.Parse(Console.ReadLine());

            foreach (Tienda tiendas in provers.Tiendas)
            {
                foreach (Productos produ in tiendas.Productos)
                {
                    if (produ.Codigo.Equals(codigo))
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write(tiendas.Nombre +" : ");
                        Console.WriteLine(produ.Stock);
                        Console.ForegroundColor = ConsoleColor.Gray;
                    }
                }
            }







        }

    }

}