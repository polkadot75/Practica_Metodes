﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace WoodShops
{
    internal class Tienda
    {
        private string direccion;
        private string poblacion;
        private string nombre;
        private ArrayList productos;


        public Tienda()
        {
            productos=new ArrayList();
        }

        public string Direccion { get => direccion; set => direccion = value; }
        public string Poblacion { get => poblacion; set => poblacion = value; }
        public ArrayList Productos { get => productos; set => productos = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public void addProductos(Productos prod)
        {
            productos.Add(prod);
        }

        public bool removeProductos(string codigo)
        {
            foreach(Productos prod in productos)
            {
                if(prod.Codigo.Equals(codigo))
                {
                    productos.Remove(prod);
                    return true;
                }
            }
            return false;
        }

        public Productos GetProductosByCodigo(string codigo) //1
        {
            foreach(Productos prod in productos)
            {
                if (prod.Codigo.Equals(codigo))
                {
                    return prod;
                }
            }
            return null;
        }

        public ArrayList getProductos()
        {
            return productos;
        }
    }
}
