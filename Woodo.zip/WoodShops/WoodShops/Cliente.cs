﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoodShops
{
    internal class Cliente
    {
        private string nif;
        private string nombre;

        public string Nif { get => nif; set => nif = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public override string ToString()
        {
            return "Codigo: "+ nif+ "Nombre: "+ nombre;
        }
    }
}
