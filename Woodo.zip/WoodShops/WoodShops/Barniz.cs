﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoodShops
{
    internal class Barniz:Productos
    {
        private int ml;

        public int Ml { get => ml; set => ml = value; }
    }
}
