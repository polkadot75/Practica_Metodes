﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoodShops
{
    internal class Productos
    {
        private int codigo;
        private string descripcion;
        private float pvp;
        private int stock;

        public int Codigo { get => codigo; set => codigo = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public float Pvp { get => pvp; set => pvp = value; }
        public int Stock { get => stock; set => stock = value; }
        public override string ToString()
        {
            return "Código: " + codigo + " Descripción: " + descripcion + " PVP: " + pvp + " Stock: " + stock;
        }
    }
}
