﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace WoodShops
{
    // Por aqui quizás falta un toString()
    internal class Provers
    {
        private string nif;
        private string nombre;
        private ArrayList listaClientes;
        private ArrayList tiendas;

        public Provers()
        {
            listaClientes = new ArrayList();
            tiendas = new ArrayList();
        }

        public string Nif { get => nif; set => nif = value; }
        
        

        public String getNif()
        { 
            return nif; 
        }
        public void setNif(string value)
        {
            nif = value;
        }
        public int addProductos(Tienda tienda)
        {
            return tiendas.Add(tienda);
        }
        public int addCliente(Cliente cliente)
        {
           return listaClientes.Add(cliente);
        }
        public int addTienda(Tienda tienda)
        {
            return tiendas.Add(tienda);
        }
        //public Productos getProductoByCodigo(string codigo)
        //{
        //    foreach(Productos products in listaProductos)
        //    {
        //        if (products.Codigo.Equals(codigo))
        //        {
        //            return products;
        //        }
        //    }
        //    return null;
        //}

        public Cliente getClienteByNif(string nif)
        {
            foreach (Cliente cliente in listaClientes)
            {
                if (cliente.Nif.Equals(nif))
                {
                    return cliente;
                }
            }
            return null;
        }

        public string Nombre { get => nombre; set => nombre = value; }

        public ArrayList Tiendas { get => tiendas; set => tiendas = value; }
        public ArrayList ListaClientes { get => listaClientes; set => listaClientes = value; }
    }
}
