﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoodShops
{
    internal class EmpresaShops
    {
        private string nif;
        private string nombre;
        private ArrayList listaClientes;
        private ArrayList tiendas;

        public ArrayList Tiendas { get => tiendas; set => tiendas = value; }
        public string Nif { get => nif; set => nif = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public ArrayList ListaClientes { get => listaClientes; set => listaClientes = value; }
    }
}
