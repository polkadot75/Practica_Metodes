﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoodShops
{
    internal class Articulo : Productos
    {
        private ArrayList TipoArticulo;

        public ArrayList TipoArticulo1 { get => TipoArticulo; set => TipoArticulo = value; }
    }
}
